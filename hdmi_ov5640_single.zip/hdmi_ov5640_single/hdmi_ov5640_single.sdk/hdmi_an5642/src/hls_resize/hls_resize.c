/*
 * hls_resize.c
 *
 *  Created on: 2023��3��4��
 *      Author: weili
 *
 *  hls_resize driver
 */

#include "hls_resize.h"

XHls_resize hls_resize;

int ResizeInitializeAndStart(u16 deviceId, u32 src_cols, u32 src_rows, u32 dst_cols, u32 dst_rows)
{
	int status;

	status = XHls_resize_Initialize(&hls_resize, deviceId);
	if (status != XST_SUCCESS) {
		return status;
	}
	XHls_resize_Set_src_rows(&hls_resize, src_rows);
	XHls_resize_Set_src_cols(&hls_resize, src_cols);
	XHls_resize_Set_dst_rows(&hls_resize, dst_rows);
	XHls_resize_Set_dst_cols(&hls_resize, dst_cols);
	XHls_resize_InterruptGlobalDisable(&hls_resize);
	XHls_resize_EnableAutoRestart(&hls_resize);
	XHls_resize_Start(&hls_resize);

	return XST_SUCCESS;
}

u32 ResizeGetRows()
{
	return XHls_resize_Get_src_rows(&hls_resize);
}

u32 ResizeGetCols()
{
	return XHls_resize_Get_src_cols(&hls_resize);
}
