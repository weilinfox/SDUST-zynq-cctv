/*
 * hls_resize.h
 *
 *  Created on: 2023��3��4��
 *      Author: weili
 *
 *  hls_resize driver
 */

#ifndef SRC_HLS_RESIZE_HLS_RESIZE_H_
#define SRC_HLS_RESIZE_HLS_RESIZE_H_

#include "xhls_resize.h"

int ResizeInitializeAndStart(u16 deviceId, u32 src_rows, u32 src_cols, u32 dst_rows, u32 dst_cols);
u32 ResizeGetCols();
u32 ResizeGetRows();

#endif /* SRC_HLS_RESIZE_HLS_RESIZE_H_ */
